#include <data.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int convertCharToNumber(char ch) {
  if (ch >= '0' && ch <= '9') {
    return ch - '0';
  } else if (ch >= 'A' && ch <= 'F') {
    return ch - 'A' + 10;
  } else {
    return -1;
  }
}

char convertNumberToChar(int n) {
  if (n >= 0 && n <= 9) {
    return n + '0';
  } else if (n >= 10 && n <= 15) {
    return n - 10 + 'A';
  } else {
    return 0;
  }
}

void addNode(struct DataNode  *new_data, int  num)
{
  struct DataNode *newNode = malloc(sizeof(struct DataNode));
  //struct DataNode *head = malloc(sizeof(struct DataNode));

  newNode->number = convertNumberToChar(num);
  newNode->next=new_data;
  new_data = newNode;
  }
/*int numBits(int x)
{
  int bits=0;

  while(x!=0)
    {
      x=x/2;
      bits++;
    }
    }*/
Data convert_to_base_n(Data src, unsigned char n) {
  Data new_data;
  int a = src.len-1;
  int x;
   while(a>=0)
    {
      x = pow(src.base,a) * convertCharToNumber(src.data->number);
      src.data = src.data->next;
      a--;
      }

  new_data.base = n;
  new_data.sign = src.sign;
  new_data.number_bits = src.number_bits;
  
  int quotient= x;
  int  remainder;
  unsigned char len;
  
  while(quotient!=0)
    {
      remainder	= quotient%n;
      quotient = quotient/n;
      
      addNode(new_data.data, remainder);
      len++;
    }
  new_data.len = len;
  
  return new_data;
}

int convert_to_int(Data src) {

  /*  int a = src.len-1;
  int x=0;
  while(a>=0)
    {
      x= pow(src.base,a) * src.data->number;
      src.data = src.data->next;
      a--;
      }*/


  return 0;
}

Data left_shift(Data src, int n) {
  Data new_data;
  // TODO
  return new_data;
}

Data right_shift(Data src, int n) {
  Data new_data;
  // TODO
  return new_data;
}
